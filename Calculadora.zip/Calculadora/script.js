function addLabel(){
    
}

function addLabelOP(){

}

function delLabel(){

}

function total(){
    

}