const result = document.getElementById('result');
const buttons = document.querySelectorAll('.button');
let expressao = '';

buttons.forEach(button => {
    button.addEventListener('click', () => {
        
        const value = button.textContent;

        if (value === 'C') {
            expressao = '';
        } else if (value === '=') {
            try {
                expressao = eval(expressao).toString();
            } catch (e) {
                expressao = 'Erro';
            }
        } else if(value ==='←'){
            try{
                expressao = expressao.slice(0,-1);
            }
            catch(e){

            }
        }
         else {
            expressao += value;
        }

        result.value = expressao;
    });
});
