document.addEventListener('DOMContentLoaded', () => {
    const carrosselContainer = document.querySelector('#img.container');
    const imagens = document.querySelectorAll('#img.container img');
    
    let indiceAtual = 0;
    const totalImagens = imagens.length;
    const tempoDeTroca = 8000;

    function avancarCarrossel() {
        indiceAtual++;
        if (indiceAtual >= totalImagens) {
            indiceAtual = 0;
        }
        
        carrosselContainer.style.transform = `translateX(${-indiceAtual * 50}%)`;
    }

    setInterval(avancarCarrossel, tempoDeTroca);
});