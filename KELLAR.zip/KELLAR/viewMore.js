document.addEventListener('DOMContentLoaded', () => {

    const moreButton = document.getElementById('more');
    const descriptionSection = document.getElementById('description');

    function scrollToDescription() {
        if (descriptionSection) {
            descriptionSection.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    }

    if (moreButton) {
        moreButton.addEventListener('click', scrollToDescription);
    }


});
